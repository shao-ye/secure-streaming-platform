/**
 * YOYO流媒体平台 - Cloudflare Worker (完整管理后台版本)
 * 包含所有管理后台需要的API端点
 */

// CORS工具函数
const ALLOWED_ORIGINS = [
  'https://yoyo.5202021.xyz',
  'https://yoyo-streaming.pages.dev',
  'http://localhost:3000',
  'http://localhost:8080',
  'http://localhost:5173'
];

function getCorsHeaders(request = null) {
  let origin = 'https://yoyo.5202021.xyz';
  
  if (request && request.headers) {
    const requestOrigin = request.headers.get('Origin');
    if (requestOrigin && ALLOWED_ORIGINS.includes(requestOrigin)) {
      origin = requestOrigin;
    }
  }
  
  return {
    'Access-Control-Allow-Origin': origin,
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With',
    'Access-Control-Allow-Credentials': 'true',
    'Access-Control-Max-Age': '86400'
  };
}

function handleOptions(request) {
  return new Response(null, {
    status: 204,
    headers: getCorsHeaders(request)
  });
}

// 简单路由器
class Router {
  constructor() {
    this.routes = [];
  }
  
  get(path, handler) {
    this.routes.push({ method: 'GET', path, handler });
  }
  
  post(path, handler) {
    this.routes.push({ method: 'POST', path, handler });
  }
  
  put(path, handler) {
    this.routes.push({ method: 'PUT', path, handler });
  }
  
  delete(path, handler) {
    this.routes.push({ method: 'DELETE', path, handler });
  }
  
  async handle(request, env, ctx) {
    const url = new URL(request.url);
    const method = request.method;
    
    for (const route of this.routes) {
      if (route.method === method && this.matchPath(route.path, url.pathname)) {
        return await route.handler(request, env, ctx);
      }
    }
    
    return null;
  }
  
  matchPath(routePath, urlPath) {
    if (routePath === urlPath) return true;
    
    const routeParts = routePath.split('/');
    const urlParts = urlPath.split('/');
    
    if (routeParts.length !== urlParts.length) return false;
    
    for (let i = 0; i < routeParts.length; i++) {
      if (routeParts[i].startsWith(':')) continue;
      if (routeParts[i] !== urlParts[i]) return false;
    }
    
    return true;
  }
}

// 模拟数据
const mockStreams = [
  {
    id: 'stream1',
    name: '测试频道1',
    rtmpUrl: 'rtmp://example.com/live/stream1',
    status: 'active',
    viewers: 15,
    createdAt: '2025-09-29T10:00:00Z'
  },
  {
    id: 'stream2',
    name: '测试频道2',
    rtmpUrl: 'rtmp://example.com/live/stream2',
    status: 'inactive',
    viewers: 0,
    createdAt: '2025-09-29T09:30:00Z'
  }
];

// 主要处理函数
export default {
  async fetch(request, env, ctx) {
    try {
      const router = new Router();
      
      // 处理CORS预检请求
      if (request.method === 'OPTIONS') {
        return handleOptions(request);
      }
      
      // API状态端点
      router.get('/api/status', (req, env, ctx) => {
        return new Response(
          JSON.stringify({
            status: 'ok',
            message: 'YOYO Streaming Platform API v2 is running',
            timestamp: new Date().toISOString(),
            version: '2.0.0',
            project: 'yoyo-api-v2',
            cors: 'fixed',
            admin: 'enabled'
          }),
          {
            status: 200,
            headers: {
              'Content-Type': 'application/json',
              ...getCorsHeaders(request)
            }
          }
        );
      });
      
      // 用户登录端点
      router.post('/login', async (req, env, ctx) => {
        try {
          const body = await req.json();
          const { username, password } = body;
          
          console.log('Login attempt:', { username, timestamp: new Date().toISOString() });
          
          if (username === 'admin' && password === 'admin123') {
            const response = {
              status: 'success',
              message: 'Login successful',
              data: {
                user: {
                  id: 1,
                  username: 'admin',
                  role: 'admin',
                  name: '管理员'
                },
                token: 'mock-jwt-token-' + Date.now()
              }
            };
            
            return new Response(
              JSON.stringify(response),
              {
                status: 200,
                headers: {
                  'Content-Type': 'application/json',
                  ...getCorsHeaders(request)
                }
              }
            );
          } else {
            return new Response(
              JSON.stringify({
                status: 'error',
                message: 'Invalid username or password'
              }),
              {
                status: 401,
                headers: {
                  'Content-Type': 'application/json',
                  ...getCorsHeaders(request)
                }
              }
            );
          }
        } catch (error) {
          console.error('Login error:', error);
          return new Response(
            JSON.stringify({
              status: 'error',
              message: 'Invalid request body',
              error: error.message
            }),
            {
              status: 400,
              headers: {
                'Content-Type': 'application/json',
                ...getCorsHeaders(request)
              }
            }
          );
        }
      });
      
      // 用户信息端点
      router.get('/api/user', (req, env, ctx) => {
        return new Response(
          JSON.stringify({
            status: 'success',
            data: {
              user: {
                id: 1,
                username: 'admin',
                role: 'admin',
                name: '管理员',
                email: 'admin@yoyo.com'
              }
            }
          }),
          {
            status: 200,
            headers: {
              'Content-Type': 'application/json',
              ...getCorsHeaders(request)
            }
          }
        );
      });
      
      // 用户信息端点 (备用)
      router.get('/api/me', (req, env, ctx) => {
        return new Response(
          JSON.stringify({
            status: 'success',
            data: {
              user: {
                id: 1,
                username: 'admin',
                role: 'admin',
                name: '管理员',
                email: 'admin@yoyo.com'
              }
            }
          }),
          {
            status: 200,
            headers: {
              'Content-Type': 'application/json',
              ...getCorsHeaders(request)
            }
          }
        );
      });
      
      // 普通用户流列表端点
      router.get('/api/streams', (req, env, ctx) => {
        return new Response(
          JSON.stringify({
            status: 'success',
            data: {
              streams: mockStreams.map(stream => ({
                id: stream.id,
                name: stream.name,
                status: stream.status,
                viewers: stream.viewers
              }))
            }
          }),
          {
            status: 200,
            headers: {
              'Content-Type': 'application/json',
              ...getCorsHeaders(request)
            }
          }
        );
      });
      
      // ========== 管理后台API端点 ==========
      
      // 管理员频道管理 - 获取所有频道
      router.get('/api/admin/streams', (req, env, ctx) => {
        return new Response(
          JSON.stringify({
            status: 'success',
            data: {
              streams: mockStreams,
              total: mockStreams.length
            }
          }),
          {
            status: 200,
            headers: {
              'Content-Type': 'application/json',
              ...getCorsHeaders(request)
            }
          }
        );
      });
      
      // 管理员频道管理 - 添加新频道
      router.post('/api/admin/streams', async (req, env, ctx) => {
        try {
          const body = await req.json();
          const { name, rtmpUrl } = body;
          
          const newStream = {
            id: 'stream' + (mockStreams.length + 1),
            name,
            rtmpUrl,
            status: 'inactive',
            viewers: 0,
            createdAt: new Date().toISOString()
          };
          
          mockStreams.push(newStream);
          
          return new Response(
            JSON.stringify({
              status: 'success',
              message: 'Stream created successfully',
              data: { stream: newStream }
            }),
            {
              status: 201,
              headers: {
                'Content-Type': 'application/json',
                ...getCorsHeaders(request)
              }
            }
          );
        } catch (error) {
          return new Response(
            JSON.stringify({
              status: 'error',
              message: 'Invalid request body'
            }),
            {
              status: 400,
              headers: {
                'Content-Type': 'application/json',
                ...getCorsHeaders(request)
              }
            }
          );
        }
      });
      
      // 系统状态API
      router.get('/api/admin/system/status', (req, env, ctx) => {
        return new Response(
          JSON.stringify({
            status: 'success',
            data: {
              system: {
                uptime: '2 days, 14 hours, 32 minutes',
                memory: {
                  used: '256 MB',
                  total: '512 MB',
                  percentage: 50
                },
                cpu: {
                  usage: '15%',
                  cores: 2
                },
                activeStreams: mockStreams.filter(s => s.status === 'active').length,
                totalStreams: mockStreams.length,
                totalViewers: mockStreams.reduce((sum, s) => sum + s.viewers, 0)
              }
            }
          }),
          {
            status: 200,
            headers: {
              'Content-Type': 'application/json',
              ...getCorsHeaders(request)
            }
          }
        );
      });
      
      // 缓存统计API
      router.get('/api/admin/cache/stats', (req, env, ctx) => {
        return new Response(
          JSON.stringify({
            status: 'success',
            data: {
              cache: {
                hitRate: '85.6%',
                totalRequests: 12450,
                cacheHits: 10657,
                cacheMisses: 1793,
                cacheSize: '128 MB',
                maxSize: '256 MB',
                entries: 2341
              }
            }
          }),
          {
            status: 200,
            headers: {
              'Content-Type': 'application/json',
              ...getCorsHeaders(request)
            }
          }
        );
      });
      
      // VPS健康检查API
      router.get('/api/admin/vps/health', (req, env, ctx) => {
        return new Response(
          JSON.stringify({
            status: 'success',
            data: {
              vps: {
                status: 'healthy',
                responseTime: '45ms',
                lastCheck: new Date().toISOString(),
                services: {
                  ffmpeg: 'running',
                  nginx: 'running',
                  nodejs: 'running'
                },
                resources: {
                  cpu: '12%',
                  memory: '68%',
                  disk: '45%',
                  network: 'normal'
                }
              }
            }
          }),
          {
            status: 200,
            headers: {
              'Content-Type': 'application/json',
              ...getCorsHeaders(request)
            }
          }
        );
      });
      
      // 系统诊断API
      router.get('/api/admin/diagnostics', (req, env, ctx) => {
        return new Response(
          JSON.stringify({
            status: 'success',
            data: {
              diagnostics: {
                timestamp: new Date().toISOString(),
                checks: [
                  {
                    name: 'API响应时间',
                    status: 'pass',
                    value: '< 100ms',
                    threshold: '< 500ms'
                  },
                  {
                    name: 'Worker内存使用',
                    status: 'pass',
                    value: '45%',
                    threshold: '< 80%'
                  },
                  {
                    name: 'KV存储连接',
                    status: 'pass',
                    value: '正常',
                    threshold: '可访问'
                  },
                  {
                    name: 'CORS配置',
                    status: 'pass',
                    value: '已配置',
                    threshold: '正确配置'
                  },
                  {
                    name: '流媒体服务',
                    status: 'warning',
                    value: '部分可用',
                    threshold: '全部可用'
                  }
                ],
                summary: {
                  total: 5,
                  passed: 4,
                  warnings: 1,
                  errors: 0
                }
              }
            }
          }),
          {
            status: 200,
            headers: {
              'Content-Type': 'application/json',
              ...getCorsHeaders(request)
            }
          }
        );
      });
      
      // 处理请求
      const response = await router.handle(request, env, ctx);
      
      if (response) {
        return response;
      }
      
      // 404处理
      return new Response(
        JSON.stringify({
          status: 'error',
          message: 'Endpoint not found',
          path: new URL(request.url).pathname
        }),
        {
          status: 404,
          headers: {
            'Content-Type': 'application/json',
            ...getCorsHeaders(request)
          }
        }
      );
      
    } catch (error) {
      console.error('Worker error:', error);
      return new Response(
        JSON.stringify({
          status: 'error',
          message: 'Internal server error',
          code: 'INTERNAL_ERROR',
          timestamp: new Date().toISOString(),
          error: error.message
        }),
        {
          status: 500,
          headers: {
            'Content-Type': 'application/json',
            ...getCorsHeaders(request)
          }
        }
      );
    }
  }
};
