/**
 * YOYO流媒体平台 - Cloudflare Worker (手动部署版本)
 * 最小可工作版本，用于修复前端登录问题
 */

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const path = url.pathname;

    // 处理CORS预检请求
    if (request.method === 'OPTIONS') {
      return new Response(null, {
        status: 200,
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
          'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With',
          'Access-Control-Max-Age': '86400',
        },
      });
    }

    // API状态检查
    if (path === '/api/status') {
      return new Response(
        JSON.stringify({
          status: 'ok',
          message: 'YOYO Streaming Platform API is running',
          timestamp: new Date().toISOString(),
          version: '1.0.0'
        }),
        {
          status: 200,
          headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
          }
        }
      );
    }

    // 用户信息API (前端需要的)
    if (path === '/api/user') {
      return new Response(
        JSON.stringify({
          status: 'ok',
          data: {
            username: 'admin',
            role: 'admin',
            isAuthenticated: true
          },
          message: 'User data retrieved successfully'
        }),
        {
          status: 200,
          headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
          }
        }
      );
    }

    // 登录API
    if (path === '/api/login' && request.method === 'POST') {
      try {
        const body = await request.json();
        const { username, password } = body;

        // 简单的登录验证 (admin/admin123)
        if (username === 'admin' && password === 'admin123') {
          return new Response(
            JSON.stringify({
              status: 'success',
              data: {
                user: {
                  username: 'admin',
                  role: 'admin'
                },
                token: 'mock-jwt-token-' + Date.now()
              },
              message: 'Login successful'
            }),
            {
              status: 200,
              headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Set-Cookie': 'auth-token=mock-jwt-token; Path=/; HttpOnly; Secure'
              }
            }
          );
        } else {
          return new Response(
            JSON.stringify({
              status: 'error',
              message: 'Invalid username or password'
            }),
            {
              status: 401,
              headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
              }
            }
          );
        }
      } catch (error) {
        return new Response(
          JSON.stringify({
            status: 'error',
            message: 'Invalid request body'
          }),
          {
            status: 400,
            headers: {
              'Content-Type': 'application/json',
              'Access-Control-Allow-Origin': '*'
            }
          }
        );
      }
    }

    // 流列表API
    if (path === '/api/streams') {
      return new Response(
        JSON.stringify({
          status: 'ok',
          data: [
            {
              id: 'stream1',
              name: '演示频道1',
              url: 'rtmp://example.com/live/stream1',
              status: 'stopped',
              description: '这是一个演示频道'
            },
            {
              id: 'stream2', 
              name: '演示频道2',
              url: 'rtmp://example.com/live/stream2',
              status: 'stopped',
              description: '这是另一个演示频道'
            }
          ],
          message: 'Streams retrieved successfully'
        }),
        {
          status: 200,
          headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
          }
        }
      );
    }

    // 默认404响应
    return new Response(
      JSON.stringify({
        status: 'error',
        message: 'Endpoint not found',
        path: path,
        availableEndpoints: [
          '/api/status',
          '/api/user', 
          '/api/login',
          '/api/streams'
        ]
      }),
      {
        status: 404,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*'
        }
      }
    );
  }
};
