# YOYO流媒体平台 - Workers部署指南

## 🔍 问题诊断结果

通过Chrome DevTools详细诊断发现：
- ✅ 前端页面正常加载
- ✅ 用户认证API正常工作 (`/api/user` 返回200)
- ❌ 所有管理员API端点返回404错误
- **根本原因**: 生产环境Workers代码缺少完整的管理员API路由实现

## 🛠️ 解决方案步骤

### 步骤1: 获取Cloudflare API Token

1. **访问Cloudflare Dashboard**
   - 登录 https://dash.cloudflare.com/
   - 点击右上角头像 → "My Profile"

2. **创建API Token**
   - 选择 "API Tokens" 标签
   - 点击 "Create Token"
   - 选择 "Edit Cloudflare Workers" 模板
   - 或者选择 "Custom token" 并配置以下权限：
     - **Account**: Cloudflare Workers:Edit
     - **Zone**: Zone:Read (如果使用自定义域名)
     - **Zone Resources**: Include All zones

3. **复制Token**
   - 创建后立即复制token（只显示一次）
   - 格式类似：`1234567890abcdef1234567890abcdef12345678`

### 步骤2: 设置环境变量

**Windows (PowerShell)**:
```powershell
$env:CLOUDFLARE_API_TOKEN="your_token_here"
```

**Windows (CMD)**:
```cmd
set CLOUDFLARE_API_TOKEN=your_token_here
```

**验证设置**:
```powershell
echo $env:CLOUDFLARE_API_TOKEN
```

### 步骤3: 部署Workers代码

```bash
cd D:\项目文件\yoyo-kindergarten\code\secure-streaming-platform\vps-transcoder-api\cloudflare-worker
wrangler deploy --env production
```

### 步骤4: 验证部署

部署成功后，测试以下API端点：

1. **基础API测试**:
   ```
   https://yoyoapi.5202021.xyz/api/status
   ```

2. **管理员API测试** (需要登录):
   ```
   https://yoyoapi.5202021.xyz/api/admin/streams
   https://yoyoapi.5202021.xyz/api/admin/cache/stats
   https://yoyoapi.5202021.xyz/api/admin/system/status
   https://yoyoapi.5202021.xyz/api/admin/diagnostics
   https://yoyoapi.5202021.xyz/api/admin/vps/health
   ```

## 🔧 故障排除

### 常见错误及解决方案

1. **API Token错误**
   ```
   Error: Authentication error
   ```
   - 检查token是否正确设置
   - 确认token权限包含Workers编辑权限

2. **KV绑定错误**
   ```
   Error: KV namespace not found
   ```
   - 确认wrangler.toml中的KV配置正确
   - 检查KV namespace ID是否匹配

3. **路由冲突**
   ```
   Error: Route already exists
   ```
   - 检查是否有重复的路由配置
   - 清理旧的Workers部署

### 验证步骤

1. **检查Workers状态**:
   ```bash
   wrangler list
   ```

2. **查看部署日志**:
   ```bash
   wrangler tail --env production
   ```

3. **测试API响应**:
   - 使用浏览器或Postman测试API端点
   - 检查响应状态码和内容

## 📝 部署后验证清单

- [ ] API Token已设置并验证
- [ ] Workers成功部署到生产环境
- [ ] 基础API端点 `/api/status` 返回200
- [ ] 用户认证API `/api/user` 正常工作
- [ ] 管理员API端点不再返回404错误
- [ ] 前端管理页面功能恢复正常
- [ ] 所有管理员功能可以正常使用

## 🎯 预期结果

部署完成后：
1. 所有管理员API端点将返回正确的JSON响应
2. 前端管理页面不再显示"请求的资源不存在"错误
3. 频道管理、系统状态、缓存统计等功能恢复正常
4. Chrome DevTools控制台不再显示404错误

## 📞 需要帮助？

如果在部署过程中遇到问题：
1. 检查上述故障排除部分
2. 查看wrangler部署日志
3. 确认所有配置文件正确
4. 联系技术支持获取进一步帮助
