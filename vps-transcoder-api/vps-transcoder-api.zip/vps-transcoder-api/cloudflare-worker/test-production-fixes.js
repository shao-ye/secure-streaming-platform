/**
 * 生产环境修复验证脚本
 * 用于测试 https://yoyo.5202021.xyz/ 的控制台错误修复
 */

const PRODUCTION_BASE_URL = 'https://yoyo.5202021.xyz';

// 测试端点列表
const TEST_ENDPOINTS = [
  '/api/me',
  '/api/streams',
  '/api/admin/streams',
  '/api/admin/status',
  '/api/admin/cache/stats',
  '/api/admin/vps/health',
  '/api/admin/diagnostics'
];

async function testEndpoint(url) {
  try {
    console.log(`🔍 Testing: ${url}`);
    
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Origin': 'https://yoyo.5202021.xyz'
      }
    });
    
    const data = await response.json();
    
    if (response.ok) {
      console.log(`✅ ${url} - Status: ${response.status}`);
      console.log(`   Response: ${data.status} - ${data.message}`);
      return { success: true, status: response.status, data };
    } else {
      console.log(`❌ ${url} - Status: ${response.status}`);
      console.log(`   Error: ${data.message || 'Unknown error'}`);
      return { success: false, status: response.status, error: data };
    }
  } catch (error) {
    console.log(`💥 ${url} - Network Error: ${error.message}`);
    return { success: false, error: error.message };
  }
}

async function testLogin() {
  try {
    console.log('\n🔐 Testing Login...');
    
    const response = await fetch(`${PRODUCTION_BASE_URL}/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Origin': 'https://yoyo.5202021.xyz'
      },
      body: JSON.stringify({
        username: 'admin',
        password: 'admin123'
      })
    });
    
    const data = await response.json();
    
    if (response.ok) {
      console.log('✅ Login successful');
      console.log(`   Token: ${data.data.token}`);
      return data.data.token;
    } else {
      console.log('❌ Login failed');
      console.log(`   Error: ${data.message}`);
      return null;
    }
  } catch (error) {
    console.log(`💥 Login Network Error: ${error.message}`);
    return null;
  }
}

async function runTests() {
  console.log('🚀 开始测试生产环境API修复...\n');
  
  // 测试登录
  const token = await testLogin();
  
  // 测试所有端点
  console.log('\n📡 Testing API Endpoints...');
  const results = [];
  
  for (const endpoint of TEST_ENDPOINTS) {
    const url = `${PRODUCTION_BASE_URL}${endpoint}`;
    const result = await testEndpoint(url);
    results.push({ endpoint, ...result });
    
    // 短暂延迟避免请求过快
    await new Promise(resolve => setTimeout(resolve, 500));
  }
  
  // 汇总结果
  console.log('\n📊 测试结果汇总:');
  const successful = results.filter(r => r.success).length;
  const failed = results.filter(r => !r.success).length;
  
  console.log(`✅ 成功: ${successful}/${results.length}`);
  console.log(`❌ 失败: ${failed}/${results.length}`);
  
  if (failed > 0) {
    console.log('\n❌ 失败的端点:');
    results.filter(r => !r.success).forEach(r => {
      console.log(`   ${r.endpoint} - ${r.error || 'Unknown error'}`);
    });
  }
  
  // 检查是否修复了变量作用域错误
  console.log('\n🔍 检查修复状态:');
  if (successful > 0) {
    console.log('✅ API端点可以正常响应，变量作用域错误已修复');
  } else {
    console.log('❌ 仍有问题，可能需要重新部署修复代码');
  }
  
  return results;
}

// 如果在Node.js环境中运行
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { runTests, testEndpoint, testLogin };
}

// 如果在浏览器中运行
if (typeof window !== 'undefined') {
  window.productionTest = { runTests, testEndpoint, testLogin };
  console.log('🌐 在浏览器控制台中运行: productionTest.runTests()');
}

// 自动运行测试（如果在Node.js中）
if (typeof process !== 'undefined' && process.argv && process.argv[1] && process.argv[1].includes('test-production-fixes.js')) {
  runTests().then(() => {
    console.log('\n✨ 测试完成');
  }).catch(error => {
    console.error('💥 测试失败:', error);
  });
}
