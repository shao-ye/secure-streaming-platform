# 🚀 生产环境部署检查清单

## 问题描述
- **问题**: https://yoyo.5202021.xyz/ 控制台出现 `ReferenceError: request is not defined` 错误
- **原因**: 生产代码中变量作用域错误，`request` 应该是 `req`
- **影响**: 所有管理员API端点无法正常工作

## 修复内容
✅ 已修复的变量作用域错误:
- `requireAdmin(request, env)` → `requireAdmin(req, env)`
- 所有响应函数中的 `request` → `req`
- CORS头处理中的变量引用错误

## 部署步骤

### 方法1: 手动部署 (推荐)
1. [ ] 打开 Cloudflare Dashboard → Workers & Pages
2. [ ] 找到 `yoyo-streaming-worker` 
3. [ ] 点击 "Edit Code"
4. [ ] 复制 `fixed-production-worker.js` 的全部内容
5. [ ] 替换编辑器中的所有代码
6. [ ] 点击 "Save and Deploy"
7. [ ] 等待部署完成 (通常1-2分钟)

### 方法2: CLI部署 (需要认证)
```bash
# 设置API Token (如果有的话)
export CLOUDFLARE_API_TOKEN=your_token_here

# 部署到生产环境
wrangler deploy --env production
```

## 部署后验证

### 1. 基础API测试
在浏览器控制台中运行:
```javascript
// 测试基础API
fetch('/api/me').then(r => r.json()).then(console.log);
fetch('/api/streams').then(r => r.json()).then(console.log);
```

### 2. 管理员API测试
```javascript
// 测试管理员API
fetch('/api/admin/streams').then(r => r.json()).then(console.log);
fetch('/api/admin/status').then(r => r.json()).then(console.log);
```

### 3. 登录测试
```javascript
// 测试登录
fetch('/login', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ username: 'admin', password: 'admin123' })
}).then(r => r.json()).then(console.log);
```

### 4. 控制台错误检查
- [ ] 打开 https://yoyo.5202021.xyz/
- [ ] 按F12打开开发者工具
- [ ] 检查Console标签页
- [ ] 确认没有 `ReferenceError: request is not defined` 错误
- [ ] 登录后台，确认管理页面正常加载

## 预期结果

✅ **成功标志:**
- 控制台无JavaScript错误
- 所有API端点返回JSON响应 (不是HTML)
- 管理后台正常加载
- 网络请求显示200状态码

❌ **如果仍有问题:**
- 检查是否完全替换了代码
- 确认部署已完成
- 清除浏览器缓存并刷新
- 检查Cloudflare Worker日志

## 测试脚本

使用提供的测试脚本验证修复:
```bash
node test-production-fixes.js
```

或在浏览器控制台中:
```javascript
// 加载测试脚本后运行
productionTest.runTests();
```

## 回滚计划

如果部署出现问题:
1. 在Cloudflare Dashboard中点击 "Rollback"
2. 或重新部署之前的工作版本
3. 检查Worker日志获取错误信息

## 联系信息

如需帮助，请提供:
- 部署时间
- 错误截图
- 浏览器控制台日志
- Cloudflare Worker日志

---

**重要提醒**: 部署后请立即测试，确保所有功能正常工作！
