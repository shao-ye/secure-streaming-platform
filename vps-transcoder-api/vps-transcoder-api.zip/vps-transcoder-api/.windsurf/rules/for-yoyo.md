---
trigger: always_on
description: 
globs: 
---

1、修改@frontend文件夹下的文件后，要提交到git上
2、修改@cloudflare-worker文件夹下的文件后，要部署到cloudflare worker上